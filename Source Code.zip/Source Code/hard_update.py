import Update_Model

emotions=["angry", "happy", "sad", "neutral"]
Update_Model.update(emotions);